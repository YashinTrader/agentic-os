from __future__ import annotations

import json
import shutil
import tempfile
import unittest
from pathlib import Path

import yaml

# We will import the parsing functions directly from dashboard.app
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from dashboard.app import (
    load_all_tasks,
    load_events,
    load_handoffs,
    load_adrs,
    get_health_metrics,
)


class TestDashboardParsing(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / "repo"
        self.root.mkdir(parents=True, exist_ok=True)

        # Create subdirectories
        (self.root / "tasks" / "active").mkdir(parents=True, exist_ok=True)
        (self.root / "tasks" / "done").mkdir(parents=True, exist_ok=True)
        (self.root / "tasks" / "blocked").mkdir(parents=True, exist_ok=True)
        (self.root / "handoffs").mkdir(parents=True, exist_ok=True)
        (self.root / "decisions").mkdir(parents=True, exist_ok=True)
        (self.root / "logs").mkdir(parents=True, exist_ok=True)

        # Create dummy task
        self.dummy_task = {
            "id": "T-TEST",
            "title": "Test Dashboard Functionality",
            "owner": "gemini",
            "status": "in_progress",
            "created": "2026-05-23T08:00:00Z",
            "updated": "2026-05-23T09:00:00Z",
            "objective": "Verify dashboard works under tests.",
            "inputs": ["README.md"],
            "outputs": ["app.py"],
            "constraints": ["Keep it clean."],
            "acceptance_criteria": ["Tests pass."],
            "handoff_notes": "None.",
            "risk_level": "low",
            "requires_human_approval": False,
        }
        with open(self.root / "tasks" / "active" / "T-TEST.yaml", "w", encoding="utf-8") as f:
            yaml.safe_dump(self.dummy_task, f, sort_keys=False)

        # Create dummy events
        self.events = [
            {"ts": "2026-05-23T08:00:00Z", "agent": "gemini", "task": "T-TEST", "event": "started", "detail": "Init"},
            {"ts": "2026-05-23T09:00:00Z", "agent": "gemini", "task": "T-TEST", "event": "finished", "detail": "Done"},
        ]
        with open(self.root / "logs" / "agent-events.jsonl", "w", encoding="utf-8") as f:
            for ev in self.events:
                f.write(json.dumps(ev) + "\n")

        # Create dummy handoff and ADR
        with open(self.root / "handoffs" / "T-TEST__gemini__to__claude.md", "w", encoding="utf-8") as f:
            f.write("# Handoff: T-TEST\n**From:** gemini\n**To:** claude\n")
        with open(self.root / "handoffs" / "README.md", "w", encoding="utf-8") as f:
            f.write("# Handoffs README\n")

        with open(self.root / "decisions" / "ADR-0001-test.md", "w", encoding="utf-8") as f:
            f.write("# ADR-0001: Test Decision\n**Status:** Accepted\n")

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def test_load_all_tasks(self) -> None:
        tasks, errors = load_all_tasks(self.root)
        self.assertEqual(len(errors), 0)
        self.assertEqual(len(tasks), 1)
        self.assertEqual(tasks[0]["id"], "T-TEST")
        self.assertEqual(tasks[0]["status"], "in_progress")

    def test_load_events(self) -> None:
        events, errors = load_events(self.root)
        self.assertEqual(len(errors), 0)
        self.assertEqual(len(events), 2)
        self.assertEqual(events[1]["event"], "finished")

    def test_load_handoffs(self) -> None:
        handoffs = load_handoffs(self.root)
        # Should exclude README.md
        self.assertEqual(len(handoffs), 1)
        self.assertEqual(handoffs[0].name, "T-TEST__gemini__to__claude.md")

    def test_load_adrs(self) -> None:
        adrs = load_adrs(self.root)
        self.assertEqual(len(adrs), 1)
        self.assertEqual(adrs[0].name, "ADR-0001-test.md")

    def test_get_health_metrics(self) -> None:
        metrics = get_health_metrics(self.root)
        self.assertEqual(metrics["active_count"], 1)
        self.assertEqual(metrics["blocked_count"], 0)
        self.assertEqual(metrics["done_count"], 0)
        self.assertEqual(metrics["last_event_ts"], "2026-05-23T09:00:00Z")
        self.assertTrue(metrics["logs_ok"])
        self.assertTrue(metrics["tasks_ok"])


if __name__ == "__main__":
    unittest.main()
