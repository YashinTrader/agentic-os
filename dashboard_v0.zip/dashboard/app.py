from __future__ import annotations

import json
import subprocess
import sys
from datetime import datetime
from pathlib import Path

import yaml

# Attempt to import streamlit, but support import without it for unittest parsing tests.
try:
    import streamlit as st
    HAS_STREAMLIT = True
except ImportError:
    HAS_STREAMLIT = False

# Resolve the repository root relative to this file
ROOT_DIR = Path(__file__).resolve().parents[1]


# ==========================================
# 1. CORE DATA PARSING & PARSER LOGIC
# ==========================================

def load_all_tasks(root_dir: Path) -> tuple[list[dict], list[str]]:
    """Scan and parse all task YAML files from the repository."""
    tasks = []
    errors = []
    
    state_dirs = {
        "todo": "active",
        "in_progress": "active",
        "review": "active",
        "blocked": "blocked",
        "done": "done",
    }
    
    for status, state_dir in state_dirs.items():
        dir_path = root_dir / "tasks" / state_dir
        if not dir_path.exists():
            continue
            
        # Glob both *.yaml and *.yml
        files = list(dir_path.glob("*.yaml")) + list(dir_path.glob("*.yml"))
        
        # Deduplicate files (if active/blocked/done folders somehow overlap)
        seen_paths = set()
        
        for file_path in files:
            resolved_path = file_path.resolve()
            if resolved_path in seen_paths:
                continue
            seen_paths.add(resolved_path)
            
            try:
                content = file_path.read_text(encoding="utf-8")
                data = yaml.safe_load(content)
                if isinstance(data, dict):
                    # Check task schema status matches the folder it is in,
                    # except EXAMPLE.yaml which is always 'todo'
                    task_status = data.get("status", "todo")
                    
                    # Optional folder validation matching
                    if file_path.name == "EXAMPLE.yaml":
                        # Skip showing example template in Kanban
                        continue
                        
                    task_item = {
                        "id": data.get("id", file_path.stem),
                        "title": data.get("title", "Untitled Task"),
                        "owner": data.get("owner", "unassigned"),
                        "status": task_status,
                        "created": data.get("created", "N/A"),
                        "updated": data.get("updated", "N/A"),
                        "objective": data.get("objective", ""),
                        "inputs": data.get("inputs", []),
                        "outputs": data.get("outputs", []),
                        "constraints": data.get("constraints", []),
                        "acceptance_criteria": data.get("acceptance_criteria", []),
                        "handoff_notes": data.get("handoff_notes", ""),
                        "risk_level": data.get("risk_level", "low"),
                        "requires_human_approval": data.get("requires_human_approval", False),
                        "priority": data.get("priority", "P3"),
                        "depends_on": data.get("depends_on", []),
                        "blocks": data.get("blocks", []),
                        "labels": data.get("labels", []),
                        "estimated_effort": data.get("estimated_effort", "S"),
                        "related_decisions": data.get("related_decisions", []),
                        "file_path": file_path.relative_to(root_dir).as_posix()
                    }
                    
                    # Ensure status alignment
                    if state_dir == "active" and task_item["status"] not in ("todo", "in_progress", "review"):
                        # If file is in active/ but status is done or blocked, respect the status
                        pass
                    
                    tasks.append(task_item)
                else:
                    errors.append(f"File {file_path.name} in {state_dir} is not a valid YAML mapping.")
            except Exception as e:
                errors.append(f"Failed to parse {file_path.relative_to(root_dir)}: {str(e)}")
                
    # Deduplicate by task ID (prioritizing status consistency)
    unique_tasks = {}
    for t in tasks:
        tid = t["id"]
        # If task exists in done or blocked, prioritize those folders over active
        if tid not in unique_tasks:
            unique_tasks[tid] = t
        else:
            current_path = unique_tasks[tid]["file_path"]
            new_path = t["file_path"]
            if "done" in new_path or "blocked" in new_path:
                unique_tasks[tid] = t
                
    return sorted(list(unique_tasks.values()), key=lambda x: x["id"]), errors


def load_events(root_dir: Path) -> tuple[list[dict], list[str]]:
    """Parse events log from agent-events.jsonl."""
    events = []
    errors = []
    log_path = root_dir / "logs" / "agent-events.jsonl"
    if not log_path.exists():
        return [], [f"Log file not found: logs/agent-events.jsonl"]
        
    try:
        lines = log_path.read_text(encoding="utf-8").splitlines()
        for idx, line in enumerate(lines, 1):
            if not line.strip():
                continue
            try:
                ev = json.loads(line)
                if isinstance(ev, dict):
                    events.append(ev)
                else:
                    errors.append(f"logs/agent-events.jsonl:{idx}: Event must be a JSON object.")
            except Exception as e:
                errors.append(f"logs/agent-events.jsonl:{idx}: Invalid JSON: {str(e)}")
    except Exception as e:
        errors.append(f"Failed to read logs/agent-events.jsonl: {str(e)}")
        
    return events, errors


def load_handoffs(root_dir: Path) -> list[Path]:
    """Find all handoff Markdown files in handoffs/ (excluding README.md)."""
    handoffs_dir = root_dir / "handoffs"
    if not handoffs_dir.exists():
        return []
    return sorted([p for p in handoffs_dir.glob("*.md") if p.name.lower() != "readme.md"], key=lambda x: x.name)


def load_adrs(root_dir: Path) -> list[Path]:
    """Find all ADR files in decisions/ (matching ADR-*.md)."""
    decisions_dir = root_dir / "decisions"
    if not decisions_dir.exists():
        return []
    return sorted(list(decisions_dir.glob("ADR-*.md")), key=lambda x: x.name)


def get_health_metrics(root_dir: Path) -> dict:
    """Calculate system stats and health information."""
    tasks, task_errors = load_all_tasks(root_dir)
    events, event_errors = load_events(root_dir)
    
    active_count = sum(1 for t in tasks if t["status"] in ("todo", "in_progress", "review"))
    blocked_count = sum(1 for t in tasks if t["status"] == "blocked")
    done_count = sum(1 for t in tasks if t["status"] == "done")
    
    last_event_ts = "N/A"
    if events:
        try:
            sorted_events = sorted(events, key=lambda x: x.get("ts", ""))
            if sorted_events:
                last_event_ts = sorted_events[-1].get("ts", "N/A")
        except Exception:
            pass
            
    return {
        "active_count": active_count,
        "blocked_count": blocked_count,
        "done_count": done_count,
        "last_event_ts": last_event_ts,
        "logs_ok": len(event_errors) == 0,
        "tasks_ok": len(task_errors) == 0,
        "task_errors": task_errors,
        "event_errors": event_errors,
    }


# ==========================================
# 2. STREAMLIT DRAWING CODE
# ==========================================

def run_streamlit_app():
    if not HAS_STREAMLIT:
        print("Streamlit is not installed. Please install using: pip install -r requirements.txt")
        sys.exit(1)
        
    st.set_page_config(
        page_title="Agentic OS Control Panel",
        page_icon="🤖",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    # Custom CSS for rich dashboard styling, colored badges, and card hover effects
    st.markdown("""
        <style>
        /* Import Outfit font from Google Fonts */
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap');
        
        html, body, [class*="css"], .stMarkdown {
            font-family: 'Outfit', -apple-system, BlinkMacSystemFont, sans-serif;
        }
        
        /* Metric widget styling override */
        div[data-testid="stMetricValue"] {
            font-size: 28px;
            font-weight: 700;
        }
        
        /* Kanban card container styling */
        .kanban-col {
            background-color: rgba(255, 255, 255, 0.02);
            border: 1px solid rgba(255, 255, 255, 0.05);
            border-radius: 12px;
            padding: 16px;
            min-height: 520px;
        }
        
        .task-card {
            background: rgba(30, 41, 59, 0.7);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 8px;
            padding: 14px;
            margin-bottom: 12px;
            transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .task-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 16px rgba(0,0,0,0.3);
            border-color: rgba(255, 255, 255, 0.2);
            background: rgba(30, 41, 59, 0.95);
        }
        
        /* Priority and risk badges styling */
        .badge {
            display: inline-block;
            padding: 2px 6px;
            font-size: 10px;
            font-weight: 600;
            border-radius: 4px;
            text-transform: uppercase;
            margin-right: 4px;
        }
        
        .p-high { background-color: #ef4444; color: white; }
        .p-med { background-color: #f59e0b; color: black; }
        .p-low { background-color: #3b82f6; color: white; }
        
        .prio-p0 { background-color: #dc2626; color: white; }
        .prio-p1 { background-color: #ea580c; color: white; }
        .prio-p2 { background-color: #d97706; color: white; }
        .prio-p3 { background-color: #4b5563; color: white; }
        
        .owner-pill {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50px;
            padding: 2px 8px;
            font-size: 11px;
            font-weight: 500;
            color: #e2e8f0;
        }
        
        /* Health box indicators */
        .health-card {
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 10px;
            border: 1px solid rgba(255,255,255,0.08);
        }
        .health-ok {
            background-color: rgba(16, 185, 129, 0.1);
            border-left: 4px solid #10b981;
            color: #34d399;
        }
        .health-err {
            background-color: rgba(239, 68, 68, 0.1);
            border-left: 4px solid #ef4444;
            color: #f87171;
        }
        
        </style>
    """, unsafe_allow_html=True)

    # ------------------------------------------
    # SIDEBAR: Health, Quick Stats & Hints
    # ------------------------------------------
    st.sidebar.markdown("<h1 style='font-size: 24px; font-weight:700; margin-bottom:4px; color:#f1f5f9;'>🤖 Agentic OS</h1>", unsafe_allow_html=True)
    st.sidebar.markdown("<div style='font-size: 12px; color:#64748b; margin-bottom:20px;'>File-based Control Plane Control Panel</div>", unsafe_allow_html=True)
    
    metrics = get_health_metrics(ROOT_DIR)
    
    st.sidebar.subheader("🏥 Health Panel")
    
    # Render Task parsing status
    if metrics["tasks_ok"]:
        st.sidebar.markdown("""
            <div class="health-card health-ok">
                <b>✓ Task Files Status</b><br><span style='font-size:11px; color:#a7f3d0;'>All YAML parses successfully</span>
            </div>
        """, unsafe_allow_html=True)
    else:
        st.sidebar.markdown("""
            <div class="health-card health-err">
                <b>✗ Task Parsing Errors</b><br><span style='font-size:11px; color:#fca5a5;'>Check error logs in Detail View</span>
            </div>
        """, unsafe_allow_html=True)
        with st.sidebar.expander("View YAML Errors"):
            for err in metrics["task_errors"]:
                st.write(err)

    # Render Events parsing status
    if metrics["logs_ok"]:
        st.sidebar.markdown("""
            <div class="health-card health-ok">
                <b>✓ Event Log Status</b><br><span style='font-size:11px; color:#a7f3d0;'>agent-events.jsonl parses successfully</span>
            </div>
        """, unsafe_allow_html=True)
    else:
        st.sidebar.markdown("""
            <div class="health-card health-err">
                <b>✗ Event Log Parse Errors</b><br><span style='font-size:11px; color:#fca5a5;'>JSONL schema checks failed</span>
            </div>
        """, unsafe_allow_html=True)
        with st.sidebar.expander("View Event Errors"):
            for err in metrics["event_errors"]:
                st.write(err)
                
    st.sidebar.markdown("<hr style='margin:15px 0; opacity:0.15;'/>", unsafe_allow_html=True)
    
    st.sidebar.subheader("📊 Repository Overview")
    st.sidebar.metric("Active Tasks", metrics["active_count"])
    st.sidebar.metric("Blocked Tasks", metrics["blocked_count"])
    st.sidebar.metric("Done Tasks", metrics["done_count"])
    st.sidebar.markdown(f"<div style='font-size:11px; color:#64748b; margin-top:-5px;'>Last Event: <code style='font-size:9px;'>{metrics['last_event_ts']}</code></div>", unsafe_allow_html=True)
    
    st.sidebar.markdown("<hr style='margin:15px 0; opacity:0.15;'/>", unsafe_allow_html=True)
    
    st.sidebar.subheader("💡 CLI Cheat Sheet")
    st.sidebar.code("""
# Validate Repo Files
python scripts/validate.py

# Run Unit Tests
python -m unittest

# Create Task File
python scripts/create_task.py \\
  --id T-XXXX --title "..."

# Update Task Status
python scripts/update_task.py \\
  --id T-XXXX --status in_progress
    """, language="bash")

    # ------------------------------------------
    # MAIN PANEL: Navigation & Tabs
    # ------------------------------------------
    tab_kanban, tab_logs, tab_handoffs, tab_control = st.tabs([
        "📋 Kanban Board", 
        "📜 System Events", 
        "📑 Handoffs & ADRs", 
        "⚙️ Control Room"
    ])

    tasks, _ = load_all_tasks(ROOT_DIR)

    # Initialize Selected Task State if not set
    if "selected_task_id" not in st.session_state:
        st.session_state.selected_task_id = None

    # ==========================================
    # TAB 1: KANBAN BOARD
    # ==========================================
    with tab_kanban:
        st.subheader("Task Backlog Kanban")
        
        # Grid of columns
        cols = st.columns(5)
        statuses = ["todo", "in_progress", "review", "blocked", "done"]
        col_names = ["📝 To Do", "⚡ In Progress", "🔍 In Review", "🛑 Blocked", "✅ Completed"]
        col_colors = ["#94a3b8", "#3b82f6", "#a855f7", "#ef4444", "#10b981"]
        
        for i, status in enumerate(statuses):
            with cols[i]:
                st.markdown(f"""
                    <div style='background-color:{col_colors[i]}15; border-radius: 6px; padding: 4px 8px; margin-bottom: 12px; border-left: 4px solid {col_colors[i]};'>
                        <h4 style='margin: 0; padding: 4px 0; color: #f1f5f9; font-size:14px; font-weight:600;'>{col_names[i]}</h4>
                    </div>
                """, unsafe_allow_html=True)
                
                # Fetch tasks in this status
                status_tasks = [t for t in tasks if t["status"] == status]
                
                if not status_tasks:
                    st.markdown("<div style='color:#475569; font-size:12px; text-align:center; padding: 30px 0;'>Empty</div>", unsafe_allow_html=True)
                
                for task in status_tasks:
                    # Risk color map
                    risk_color = "#34d399" if task["risk_level"] == "low" else ("#fbbf24" if task["risk_level"] == "medium" else "#f87171")
                    priority_val = task.get("priority", "P3")
                    priority_class = f"prio-{priority_val.lower()}"
                    
                    card_html = f"""
                    <div class="task-card">
                        <div style='display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;'>
                            <span style='font-size: 11px; font-weight: 700; color: {col_colors[i]};'>{task['id']}</span>
                            <div>
                                <span class="badge {priority_class}">{priority_val}</span>
                                <span class="owner-pill">{task['owner']}</span>
                            </div>
                        </div>
                        <div style="font-weight: 600; font-size: 13px; margin-bottom: 6px; color: #f1f5f9; line-height: 1.3;">
                            {task['title']}
                        </div>
                        <div style="font-size: 11px; color: #94a3b8; font-style: italic; margin-bottom: 8px; line-height: 1.4;">
                            {task['objective'][:80]}...
                        </div>
                        <div style="font-size: 10px; color: #475569; display: flex; justify-content: space-between;">
                            <span>Risk: <b style='color:{risk_color};'>{task['risk_level'].upper()}</b></span>
                            <span>{task['updated'][:10]}</span>
                        </div>
                    </div>
                    """
                    st.markdown(card_html, unsafe_allow_html=True)
                    if st.button(f"Inspect {task['id']}", key=f"inspect_btn_{task['id']}", use_container_width=True):
                        st.session_state.selected_task_id = task["id"]
                        st.rerun()

        # Task Detail View (Renders at bottom of board if a task is selected)
        if st.session_state.selected_task_id:
            st.markdown("<hr style='margin: 30px 0; opacity:0.15;'/>", unsafe_allow_html=True)
            
            selected_task = next((t for t in tasks if t["id"] == st.session_state.selected_task_id), None)
            
            if selected_task:
                col_left, col_right = st.columns([2, 1])
                with col_left:
                    st.markdown(f"### 📋 [{selected_task['id']}] {selected_task['title']}")
                    st.markdown(f"**Objective:** {selected_task['objective']}")
                    
                    st.markdown("#### 🛠️ Execution & Parameters")
                    st.markdown("**Inputs:**")
                    for ip in selected_task.get("inputs", []):
                        st.markdown(f"- `{ip}`")
                        
                    st.markdown("**Outputs:**")
                    for op in selected_task.get("outputs", []):
                        st.markdown(f"- `{op}`")
                        
                    st.markdown("**Constraints:**")
                    for ct in selected_task.get("constraints", []):
                        st.markdown(f"- `{ct}`")
                        
                    st.markdown("**Acceptance Criteria:**")
                    for ac in selected_task.get("acceptance_criteria", []):
                        st.markdown(f"- `{ac}`")
                        
                    st.markdown("#### 🤝 Handoff Notes")
                    st.markdown(selected_task.get("handoff_notes", "No handoff notes yet."))
                    
                with col_right:
                    st.markdown("### 🏷️ Metadata")
                    st.markdown(f"- **Owner:** `{selected_task['owner']}`")
                    st.markdown(f"- **Status:** `{selected_task['status']}`")
                    st.markdown(f"- **Risk Level:** `{selected_task['risk_level']}`")
                    st.markdown(f"- **Requires Human Approval:** `{selected_task['requires_human_approval']}`")
                    st.markdown(f"- **Priority:** `{selected_task.get('priority', 'P3')}`")
                    st.markdown(f"- **Labels:** `{', '.join(selected_task.get('labels', [])) or 'None'}`")
                    st.markdown(f"- **File Path:** `{selected_task['file_path']}`")
                    st.markdown(f"- **Related Decisions:** `{', '.join(selected_task.get('related_decisions', [])) or 'None'}`")
                    st.markdown(f"- **Created:** `{selected_task['created']}`")
                    st.markdown(f"- **Updated:** `{selected_task['updated']}`")
                    
                    if st.button("Close Detail View", type="primary", use_container_width=True):
                        st.session_state.selected_task_id = None
                        st.rerun()

    # ==========================================
    # TAB 2: SYSTEM EVENTS & LOGS
    # ==========================================
    with tab_logs:
        st.subheader("System Event Log (logs/agent-events.jsonl)")
        
        events, _ = load_events(ROOT_DIR)
        
        # Display Filters
        col_f1, col_f2 = st.columns(2)
        with col_f1:
            all_agents = sorted(list(set(ev.get("agent", "") for ev in events)))
            agent_filter = st.multiselect("Filter by Agent", all_agents)
        with col_f2:
            all_tasks = sorted(list(set(ev.get("task", "") for ev in events)))
            task_filter = st.multiselect("Filter by Task", all_tasks)
            
        filtered_events = events
        if agent_filter:
            filtered_events = [e for e in filtered_events if e.get("agent") in agent_filter]
        if task_filter:
            filtered_events = [e for e in filtered_events if e.get("task") in task_filter]
            
        # Reverse events list to display newest first
        filtered_events = list(reversed(filtered_events))
        
        st.markdown(f"Showing **{min(30, len(filtered_events))}** of **{len(filtered_events)}** matching events.")
        
        for ev in filtered_events[:30]:
            ref_str = f" | Ref: <code>{ev['ref']}</code>" if "ref" in ev else ""
            st.markdown(f"""
                <div style='background: rgba(30, 41, 59, 0.4); border: 1px solid rgba(255, 255, 255, 0.05); padding: 10px 14px; border-radius: 6px; margin-bottom: 8px;'>
                    <div style='display:flex; justify-content:space-between; font-size: 11px; color:#64748b; margin-bottom: 4px;'>
                        <span>⏱ {ev['ts']}</span>
                        <span>Agent: <b>{ev['agent']}</b> | Task: <b>{ev['task']}</b></span>
                    </div>
                    <div style='font-size:13px; color:#cbd5e1;'>
                        Event: <code style='color:#38bdf8;'>{ev['event']}</code> - {ev['detail']}{ref_str}
                    </div>
                </div>
            """, unsafe_allow_html=True)

    # ==========================================
    # TAB 3: HANDOFFS & decisions (ADRs)
    # ==========================================
    with tab_handoffs:
        col_ho, col_adr = st.columns(2)
        
        with col_ho:
            st.subheader("🤝 Agent Handoffs")
            handoff_files = load_handoffs(ROOT_DIR)
            
            if not handoff_files:
                st.write("No handoff files found in `handoffs/`.")
            else:
                handoff_names = [p.name for p in handoff_files]
                selected_ho_name = st.selectbox("Select Handoff to Read", handoff_names)
                
                if selected_ho_name:
                    ho_path = next(p for p in handoff_files if p.name == selected_ho_name)
                    st.markdown(f"**Path:** `handoffs/{selected_ho_name}`")
                    st.markdown("<div style='background-color:rgba(0,0,0,0.15); padding: 15px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.05);'>", unsafe_allow_html=True)
                    st.markdown(ho_path.read_text(encoding="utf-8"))
                    st.markdown("</div>", unsafe_allow_html=True)
                    
        with col_adr:
            st.subheader("📜 Architectural Decisions (ADRs)")
            adr_files = load_adrs(ROOT_DIR)
            
            if not adr_files:
                st.write("No ADR files found in `decisions/`.")
            else:
                adr_names = [p.name for p in adr_files]
                selected_adr_name = st.selectbox("Select ADR to Read", adr_names)
                
                if selected_adr_name:
                    adr_path = next(p for p in adr_files if p.name == selected_adr_name)
                    text = adr_path.read_text(encoding="utf-8")
                    
                    # Detect status from front-matter/metadata
                    status = "Unknown"
                    if "**Status:** Accepted" in text:
                        status = "✅ Accepted"
                    elif "**Status:** Proposed" in text:
                        status = "💡 Proposed"
                    elif "**Status:** Rejected" in text:
                        status = "❌ Rejected"
                        
                    st.markdown(f"**Path:** `decisions/{selected_adr_name}` | **Status:** {status}")
                    st.markdown("<div style='background-color:rgba(0,0,0,0.15); padding: 15px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.05);'>", unsafe_allow_html=True)
                    st.markdown(text)
                    st.markdown("</div>", unsafe_allow_html=True)

    # ==========================================
    # TAB 4: CONTROL ROOM (SAFE WRITE ACTIONS)
    # ==========================================
    with tab_control:
        st.subheader("⚙️ Local Agentic OS Operations")
        st.warning("All write actions execute the repository's native Python CLI helper scripts via secure subprocesses.")
        
        action = st.radio("Choose Action", ["Create Task", "Update Task Status", "Create Handoff"], horizontal=True)
        
        st.markdown("<hr style='margin: 15px 0; opacity:0.15;'/>", unsafe_allow_html=True)
        
        if action == "Create Task":
            st.markdown("### 📝 Create a new Task file")
            
            with st.form("create_task_form"):
                f_id = st.text_input("Task ID", value="T-0013")
                f_title = st.text_input("Title", placeholder="e.g. Implement logger module")
                f_owner = st.text_input("Owner (agent)", value="codex")
                f_status = st.selectbox("Initial Status", ["todo", "in_progress", "review"])
                f_objective = st.text_area("Objective", placeholder="Describe what this task accomplishes.")
                f_risk = st.selectbox("Risk Level", ["low", "medium", "high"])
                f_approval = st.checkbox("Requires Human Approval")
                f_priority = st.text_input("Priority", value="P1")
                f_effort = st.text_input("Estimated Effort (XS/S/M/L/XL)", value="S")
                
                # Single parameters for simple list input
                f_inputs = st.text_input("Inputs (comma separated)", value="README.md")
                f_outputs = st.text_input("Outputs (comma separated)", value="")
                f_constraints = st.text_input("Constraints (comma separated)", value="Follow the existing Agentic OS protocols.")
                f_acceptance = st.text_input("Acceptance Criteria (comma separated)", value="Task file validates.")
                
                submit = st.form_submit_button("Submit & Run CLI Command", type="primary")
                
                if submit:
                    if not f_id or not f_title or not f_objective:
                        st.error("Task ID, Title, and Objective are required!")
                    else:
                        # Build arguments list
                        cmd = [
                            sys.executable,
                            str(ROOT_DIR / "scripts" / "create_task.py"),
                            "--root", str(ROOT_DIR),
                            "--id", f_id,
                            "--title", f_title,
                            "--owner", f_owner,
                            "--status", f_status,
                            "--objective", f_objective,
                            "--risk-level", f_risk,
                            "--priority", f_priority,
                            "--estimated-effort", f_effort
                        ]
                        
                        if f_approval:
                            cmd.append("--requires-human-approval")
                            
                        # Add list fields
                        for ip in f_inputs.split(","):
                            if ip.strip():
                                cmd.extend(["--input", ip.strip()])
                        for op in f_outputs.split(","):
                            if op.strip():
                                cmd.extend(["--output", op.strip()])
                        for ct in f_constraints.split(","):
                            if ct.strip():
                                cmd.extend(["--constraint", ct.strip()])
                        for ac in f_acceptance.split(","):
                            if ac.strip():
                                cmd.extend(["--acceptance", ac.strip()])
                                
                        try:
                            res = subprocess.run(cmd, text=True, capture_output=True, check=True)
                            st.success(f"Success! Created task: `{res.stdout.strip()}`")
                        except subprocess.CalledProcessError as e:
                            st.error(f"Command execution failed!\n\nStderr:\n{e.stderr}\n\nStdout:\n{e.stdout}")
                            
        elif action == "Update Task Status":
            st.markdown("### 🔄 Update Status of an existing Task")
            
            task_options = [t["id"] for t in tasks]
            
            with st.form("update_task_form"):
                f_id = st.selectbox("Select Task to Update", task_options)
                f_status = st.selectbox("New Status", ["todo", "in_progress", "review", "blocked", "done"])
                f_owner = st.text_input("New Owner (optional)", placeholder="Leave blank to preserve")
                f_title = st.text_input("New Title (optional)", placeholder="Leave blank to preserve")
                f_risk = st.selectbox("New Risk Level (optional)", ["", "low", "medium", "high"])
                f_notes = st.text_area("Handoff/Status Notes (optional)", placeholder="Leave blank to preserve")
                
                submit = st.form_submit_button("Update Status", type="primary")
                
                if submit:
                    cmd = [
                        sys.executable,
                        str(ROOT_DIR / "scripts" / "update_task.py"),
                        "--root", str(ROOT_DIR),
                        "--id", f_id,
                        "--status", f_status
                    ]
                    if f_owner.strip():
                        cmd.extend(["--owner", f_owner.strip()])
                    if f_title.strip():
                        cmd.extend(["--title", f_title.strip()])
                    if f_risk:
                        cmd.extend(["--risk-level", f_risk])
                    if f_notes.strip():
                        cmd.extend(["--handoff-notes", f_notes.strip()])
                        
                    try:
                        res = subprocess.run(cmd, text=True, capture_output=True, check=True)
                        st.success(f"Success! Task updated: `{res.stdout.strip()}`")
                    except subprocess.CalledProcessError as e:
                        st.error(f"Command execution failed!\n\nStderr:\n{e.stderr}\n\nStdout:\n{e.stdout}")
                        
        elif action == "Create Handoff":
            st.markdown("### 🤝 Create Handoff Markdown File")
            
            task_options = [t["id"] for t in tasks]
            
            with st.form("create_handoff_form"):
                f_task = st.selectbox("Select Task", task_options)
                f_from = st.text_input("From Agent", value="gemini")
                f_to = st.text_input("To Agent", value="claude")
                f_status = st.selectbox("Task Status After Handoff", ["todo", "in_progress", "review", "blocked", "done"])
                
                f_did = st.text_area("What I Did (one item per line)", placeholder="Built feature X\nFixed bug Y")
                f_remains = st.text_area("What Remains (one item per line)", placeholder="Code review\nCI hook setup")
                f_decisions = st.text_area("Decisions Made (one item per line)", placeholder="Used Streamlit for UI")
                f_questions = st.text_area("Open Questions (one item per line)", placeholder="Should we add database?")
                f_verify = st.text_area("How to Verify My Work (one item per line)", placeholder="Run python -m unittest")
                f_risk = st.text_area("Risks / Caveats (one item per line)", placeholder="Requires streamlit dependency")
                f_next = st.text_area("Recommended Next Action (one item per line)", placeholder="Review dashboard/app.py")
                
                submit = st.form_submit_button("Generate Handoff Markdown", type="primary")
                
                if submit:
                    cmd = [
                        sys.executable,
                        str(ROOT_DIR / "scripts" / "create_handoff.py"),
                        "--root", str(ROOT_DIR),
                        "--task", f_task,
                        "--from-agent", f_from,
                        "--to-agent", f_to,
                        "--status", f_status
                    ]
                    
                    # Split multiline inputs and append
                    for item in f_did.split("\n"):
                        if item.strip():
                            cmd.extend(["--what-i-did", item.strip()])
                    for item in f_remains.split("\n"):
                        if item.strip():
                            cmd.extend(["--what-remains", item.strip()])
                    for item in f_decisions.split("\n"):
                        if item.strip():
                            cmd.extend(["--decision", item.strip()])
                    for item in f_questions.split("\n"):
                        if item.strip():
                            cmd.extend(["--open-question", item.strip()])
                    for item in f_verify.split("\n"):
                        if item.strip():
                            cmd.extend(["--verify", item.strip()])
                    for item in f_risk.split("\n"):
                        if item.strip():
                            cmd.extend(["--risk", item.strip()])
                    for item in f_next.split("\n"):
                        if item.strip():
                            cmd.extend(["--next-action", item.strip()])
                            
                    try:
                        res = subprocess.run(cmd, text=True, capture_output=True, check=True)
                        st.success(f"Success! Handoff created: `{res.stdout.strip()}`")
                    except subprocess.CalledProcessError as e:
                        st.error(f"Command execution failed!\n\nStderr:\n{e.stderr}\n\nStdout:\n{e.stdout}")


if __name__ == "__main__":
    run_streamlit_app()
