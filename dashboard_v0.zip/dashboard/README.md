# Agentic OS Kanban Dashboard

A minimal, local-first web dashboard for the Agentic OS phase 1 file control plane built using Streamlit. It reads repository files (YAML tasks, event logs, handoffs, decisions) in real-time and enables secure write actions by calling the native Python CLI helper scripts.

---

## Features

1. **🏥 Health Metrics & Safety Panel:** Real-time diagnostics monitoring if tasks (YAML) and logs (JSONL) parse perfectly, counting active, blocked, and done tasks.
2. **📋 Interactive Kanban Board:** Standard five columns (`todo`, `in_progress`, `review`, `blocked`, `done`) containing styled high-fidelity task cards. Clicking on a card launches a deep-inspection detail view of the task's execution specs (inputs, outputs, constraints, criteria, and handoff notes).
3. **📜 System Event Logs Viewer:** Clean scrollable listing of the newest 30 log events from `agent-events.jsonl` with filtering by task ID and responsible agent.
4. **📑 Handoffs & Decisions Browser:** Open, navigate, and read markdown handoffs (`handoffs/*.md`) and architectural decision records (ADRs) (`decisions/ADR-*.md`) with status indicators.
5. **⚙️ Control Room (Operations Panel):** Native form controls for secure execution of task operations:
   - **Create Task:** Calls `scripts/create_task.py`
   - **Update Task Status:** Calls `scripts/update_task.py` (which correctly moves files across folders based on status)
   - **Create Handoff:** Calls `scripts/create_handoff.py`

---

## Getting Started

### 1. Install Dependencies
Run the following command from the repository root:
```bash
pip install -r dashboard/requirements.txt
```

### 2. Launch Dashboard
Start the local Streamlit server:
```bash
streamlit run dashboard/app.py
```
The dashboard will open automatically in your browser (usually at `http://localhost:8501`).

---

## Known Limitations

- **Browser-only writes:** The "Control Room" runs scripts locally using `subprocess` calls. If running the dashboard inside a sandbox or container where subprocess executions are constrained, write actions may fail.
- **Refresh triggers:** In Streamlit, state changes and page elements trigger script re-execution. Toggling cards or submitting forms will trigger a hot reload of repository directories.
- **V0 Scope:** No external database, user accounts, or APIs are added to preserve the minimal file-only control plane architecture of Phase 1.

---

## Future Improvements

1. **Token & Budget Tracker:** Read log metadata (if added in Phase 2) to display real-time token usage and cost per agent/task.
2. **Commit Integration:** Add a "Commit & Push" button to auto-commit and push files to remote Git branches after status changes/handoffs.
3. **Task Dependency Graph:** Build a visual Node diagram (using Pydeck or Graphviz) of task dependencies and blockages using the `depends_on` and `blocks` fields.
